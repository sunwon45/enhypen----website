HOW TO PUT THIS SITE ONLINE (EASY)

1. Go to https://github.com
2. Create a new repository
3. Upload index.html
4. Go to Settings > Pages
5. Select 'Deploy from branch'
6. Your site is LIVE

That's it. 💜
